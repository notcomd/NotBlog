create function update_product_rating() returns trigger
    language plpgsql
as
$$
DECLARE
    avg_rating DECIMAL(3, 2);
    rating_cnt INTEGER;
BEGIN
    SELECT AVG(rating), COUNT(*) INTO avg_rating, rating_cnt
    FROM book_product_comment
    WHERE product_id = NEW.product_id AND status = 1 AND deleted_at IS NULL;
    
    UPDATE book_product
    SET rating = COALESCE(avg_rating, 0),
        rating_count = rating_cnt,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.product_id;
    
    RETURN NEW;
END;
$$;

alter function update_product_rating() owner to postgres;

