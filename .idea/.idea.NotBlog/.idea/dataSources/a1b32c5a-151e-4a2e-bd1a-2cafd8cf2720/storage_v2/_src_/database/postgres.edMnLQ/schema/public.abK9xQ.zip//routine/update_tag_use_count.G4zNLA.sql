create function update_tag_use_count() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE book_product_tag SET use_count = use_count + 1 WHERE id = NEW.tag_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE book_product_tag SET use_count = use_count - 1 WHERE id = OLD.tag_id;
    END IF;
    RETURN NULL;
END;
$$;

alter function update_tag_use_count() owner to postgres;

