create function update_member_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.update_time = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

alter function update_member_timestamp() owner to postgres;

