create function update_wallet_balance() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.update_time = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

alter function update_wallet_balance() owner to postgres;

