create function clean_old_ranking_data() returns void
    language plpgsql
as
$$
BEGIN
    -- 清理30天前的日榜数据
    DELETE FROM book_ranking 
    WHERE ranking_type = 'DAILY' 
    AND ranking_date < CURRENT_DATE - INTERVAL '30 days';
    
    -- 清理12周前的周榜数据
    DELETE FROM book_ranking 
    WHERE ranking_type = 'WEEKLY' 
    AND (year * 100 + week_of_year) < (EXTRACT(YEAR FROM CURRENT_DATE) * 100 + EXTRACT(WEEK FROM CURRENT_DATE)) - 12;
    
    -- 清理12个月前的月榜数据
    DELETE FROM book_ranking 
    WHERE ranking_type = 'MONTHLY' 
    AND (year * 100 + month_of_year) < (EXTRACT(YEAR FROM CURRENT_DATE) * 100 + EXTRACT(MONTH FROM CURRENT_DATE)) - 12;
    
    -- 清理90天前的统计明细数据
    DELETE FROM book_ranking_stats 
    WHERE stats_date < CURRENT_DATE - INTERVAL '90 days';
    
    RAISE NOTICE 'Old ranking data cleaned successfully';
END;
$$;

alter function clean_old_ranking_data() owner to postgres;

